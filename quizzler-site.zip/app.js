// Global variables
let isScrolling = false;

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initSmoothScrolling();
    initScrollAnimations();
    initCounterAnimations();
    initMobileMenu();
    initParallaxEffects();
    initHeaderScroll();
    initDownloadButtons();
    initQuizTileAnimations();
    initDemoButton();
    addScrollProgress();
});

// Initialize Download Buttons
function initDownloadButtons() {
    const downloadButtons = document.querySelectorAll('.download-btn');
    downloadButtons.forEach(button => {
        button.addEventListener('click', downloadApp);
    });
}

// Initialize Demo Button
function initDemoButton() {
    const demoBtn = document.querySelector('.demo-btn');
    if (demoBtn) {
        demoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showDemoModal();
        });
    }
}

// Show Demo Modal
function showDemoModal() {
    const modal = document.createElement('div');
    modal.className = 'demo-modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-play"></i> Quizzler Demo</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="demo-content">
                        <div class="demo-video-placeholder">
                            <i class="fas fa-play-circle"></i>
                            <p>Demo Video</p>
                            <span>Coming Soon</span>
                        </div>
                        <div class="demo-info">
                            <h4>Watch Quizzler in Action</h4>
                            <p>See how our AI-powered learning platform adapts to your needs and helps you excel in engineering subjects.</p>
                            <ul class="demo-features">
                                <li><i class="fas fa-check"></i> Adaptive question difficulty</li>
                                <li><i class="fas fa-check"></i> Real-time performance analytics</li>
                                <li><i class="fas fa-check"></i> Personalized learning paths</li>
                                <li><i class="fas fa-check"></i> Multi-subject support</li>
                            </ul>
                            <button class="btn btn--primary btn--full-width download-btn">
                                <i class="fab fa-android"></i>
                                Download Now
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Add demo modal styles
    if (!document.querySelector('#demo-modal-styles')) {
        const modalStyles = document.createElement('style');
        modalStyles.id = 'demo-modal-styles';
        modalStyles.textContent = `
            .demo-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 10000;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .demo-modal.active {
                opacity: 1;
                visibility: visible;
            }
            
            .demo-content {
                display: flex;
                gap: var(--space-24);
                align-items: center;
            }
            
            .demo-video-placeholder {
                width: 200px;
                height: 150px;
                background: var(--color-bg-1);
                border-radius: var(--radius-base);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: var(--space-8);
            }
            
            .demo-video-placeholder i {
                font-size: var(--font-size-4xl);
                color: var(--color-primary);
            }
            
            .demo-video-placeholder p {
                margin: 0;
                font-weight: var(--font-weight-medium);
                color: var(--color-text);
            }
            
            .demo-video-placeholder span {
                font-size: var(--font-size-sm);
                color: var(--color-text-secondary);
            }
            
            .demo-info {
                flex: 1;
            }
            
            .demo-info h4 {
                margin-bottom: var(--space-8);
                color: var(--color-text);
            }
            
            .demo-info > p {
                color: var(--color-text-secondary);
                margin-bottom: var(--space-16);
            }
            
            .demo-features {
                list-style: none;
                padding: 0;
                margin: 0 0 var(--space-20) 0;
            }
            
            .demo-features li {
                display: flex;
                align-items: center;
                gap: var(--space-8);
                margin-bottom: var(--space-8);
                color: var(--color-text-secondary);
                font-size: var(--font-size-sm);
            }
            
            .demo-features i {
                color: var(--color-success);
            }
            
            @media (max-width: 768px) {
                .demo-content {
                    flex-direction: column;
                    text-align: center;
                }
                
                .demo-video-placeholder {
                    width: 100%;
                    max-width: 300px;
                }
            }
        `;
        document.head.appendChild(modalStyles);
    }

    document.body.appendChild(modal);
    
    // Add close functionality
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.classList.remove('active');
        setTimeout(() => modal.remove(), 300);
    });
    
    modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        }
    });

    // Add download functionality to the modal button
    modal.querySelector('.download-btn').addEventListener('click', downloadApp);
    
    // Show modal with animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 50);
}

// Smooth Scrolling Navigation - Fixed
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight - 20;
                
                // Prevent multiple scroll events
                if (!isScrolling) {
                    isScrolling = true;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                    
                    // Reset scrolling flag after animation
                    setTimeout(() => {
                        isScrolling = false;
                    }, 1000);
                }
            }
        });
    });
}

// Scroll-based Animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                
                // Add staggered animation delays for grid items
                if (entry.target.parentElement.classList.contains('features__grid') ||
                    entry.target.parentElement.classList.contains('technology__grid') ||
                    entry.target.parentElement.classList.contains('team__grid')) {
                    
                    const siblings = Array.from(entry.target.parentElement.children);
                    const index = siblings.indexOf(entry.target);
                    entry.target.style.animationDelay = `${index * 100}ms`;
                }
            }
        });
    }, observerOptions);

    // Observe all animatable elements
    const animatableElements = document.querySelectorAll(
        '.feature-card, .tech-card, .team-card, .benefit, .testimonial'
    );
    
    animatableElements.forEach(el => observer.observe(el));
}

// Quiz Tile Animations
function initQuizTileAnimations() {
    const quizTiles = document.querySelectorAll('.quiz-tile');
    
    // Animate quiz tiles on load with staggered delays
    quizTiles.forEach((tile, index) => {
        setTimeout(() => {
            tile.classList.add('animate');
        }, 1000 + (index * 150)); // Start after phone animation, stagger by 150ms
    });
    
    // Add hover interactions
    quizTiles.forEach(tile => {
        tile.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-6px) scale(1.02)';
            this.style.boxShadow = '0 10px 20px rgba(0,0,0,0.15)';
        });
        
        tile.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '';
        });
        
        // Add click interaction for demo
        tile.addEventListener('click', function() {
            const quizName = this.querySelector('h4').textContent;
            showQuizPreview(quizName);
        });
    });
}

// Show Quiz Preview Modal
function showQuizPreview(quizName) {
    const modal = document.createElement('div');
    modal.className = 'quiz-preview-modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-book-open"></i> ${quizName}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="quiz-preview-content">
                        <div class="quiz-details">
                            <h4>Quiz Overview</h4>
                            <p>This ${quizName.toLowerCase()} is designed to test your knowledge and help you learn through adaptive questioning.</p>
                            <div class="quiz-features">
                                <div class="quiz-feature"><i class="fas fa-brain"></i><span>AI-Powered Questions</span></div>
                                <div class="quiz-feature"><i class="fas fa-chart-line"></i><span>Real-time Analytics</span></div>
                                <div class="quiz-feature"><i class="fas fa-target"></i><span>Adaptive Difficulty</span></div>
                                <div class="quiz-feature"><i class="fas fa-clock"></i><span>Timed Challenges</span></div>
                            </div>
                            <div class="quiz-actions">
                                <button class="btn btn--primary btn--full-width" onclick="startQuizDemo()">
                                    <i class="fas fa-play"></i>
                                    Start Demo Quiz
                                </button>
                                <button class="btn btn--outline btn--full-width download-btn">
                                    <i class="fab fa-android"></i>
                                    Download Full App
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal styles if not already present
    if (!document.querySelector('#quiz-modal-styles')) {
        const modalStyles = document.createElement('style');
        modalStyles.id = 'quiz-modal-styles';
        modalStyles.textContent = `
            .quiz-preview-modal, .demo-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 10000;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .quiz-preview-modal.active, .demo-modal.active {
                opacity: 1;
                visibility: visible;
            }
            
            .modal-overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                backdrop-filter: blur(10px);
                display: flex;
                align-items: center;
                justify-content: center;
                padding: var(--space-20);
            }
            
            .modal-content {
                background: var(--color-surface);
                border-radius: var(--radius-lg);
                border: 1px solid var(--color-card-border);
                max-width: 500px;
                width: 100%;
                transform: scale(0.9);
                transition: transform 0.3s ease;
            }
            
            .quiz-preview-modal.active .modal-content, .demo-modal.active .modal-content {
                transform: scale(1);
            }
            
            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: var(--space-24);
                border-bottom: 1px solid var(--color-card-border-inner);
            }
            
            .modal-header h3 {
                margin: 0;
                color: var(--color-text);
                display: flex;
                align-items: center;
                gap: var(--space-8);
            }
            
            .modal-close {
                background: none;
                border: none;
                font-size: var(--font-size-2xl);
                color: var(--color-text-secondary);
                cursor: pointer;
                padding: 0;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                transition: all 0.2s ease;
            }
            
            .modal-close:hover {
                background: var(--color-secondary);
                color: var(--color-text);
            }
            
            .modal-body {
                padding: var(--space-24);
            }
            
            .quiz-features {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: var(--space-12);
                margin: var(--space-20) 0;
            }
            
            .quiz-feature {
                display: flex;
                align-items: center;
                gap: var(--space-8);
            }
            
            .quiz-feature i {
                color: var(--color-primary);
                width: 16px;
            }
            
            .quiz-feature span {
                color: var(--color-text-secondary);
                font-size: var(--font-size-sm);
            }
            
            .quiz-actions {
                display: flex;
                flex-direction: column;
                gap: var(--space-12);
                margin-top: var(--space-24);
            }
        `;
        
        document.head.appendChild(modalStyles);
    }
    
    document.body.appendChild(modal);
    
    // Add close functionality
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.classList.remove('active');
        setTimeout(() => modal.remove(), 300);
    });
    
    modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        }
    });

    // Add download functionality to the modal button
    modal.querySelector('.download-btn').addEventListener('click', downloadApp);
    
    // Show modal with animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 50);
}

function startQuizDemo() {
    alert('Quiz demo would start here! Download the full app to experience all features.');
    const modal = document.querySelector('.quiz-preview-modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => modal.remove(), 300);
    }
}

// Counter Animations
function initCounterAnimations() {
    const counters = document.querySelectorAll('.stat__number[data-target]');
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                counterObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => counterObserver.observe(counter));
}

function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-target'));
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        const displayValue = Math.floor(current).toLocaleString();
        element.textContent = displayValue;
    }, 16);
}

// Mobile Menu
function initMobileMenu() {
    const menuToggle = document.querySelector('.nav__toggle');
    const navMenu = document.querySelector('.nav__menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            
            const icon = menuToggle.querySelector('i');
            if (navMenu.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });

        // Close menu when clicking nav links
        const navLinks = document.querySelectorAll('.nav__link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                const icon = menuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            });
        });
    }
}

// Parallax Effects
function initParallaxEffects() {
    // Simple particle positioning
    const particles = document.querySelectorAll('.particle');
    particles.forEach((particle, index) => {
        particle.style.top = `${20 + (index * 10)}%`;
        particle.style.left = `${10 + (index * 15)}%`;
        particle.style.animationDelay = `${index * 0.5}s`;
        particle.style.animation = 'float 6s ease-in-out infinite';
    });

    // Add CSS for floating animation
    if (!document.querySelector('#particle-styles')) {
        const particleStyles = document.createElement('style');
        particleStyles.id = 'particle-styles';
        particleStyles.textContent = `
            @keyframes float {
                0%, 100% { transform: translateY(0px) rotate(0deg); opacity: 0.6; }
                50% { transform: translateY(-20px) rotate(180deg); opacity: 1; }
            }
        `;
        document.head.appendChild(particleStyles);
    }
}

// Header Scroll Effect
function initHeaderScroll() {
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.style.background = 'rgba(var(--color-slate-900-rgb), 0.8)';
            header.style.backdropFilter = 'blur(20px)';
        } else {
            header.style.background = 'rgba(var(--color-slate-900-rgb), 0.4)';
            header.style.backdropFilter = 'blur(10px)';
        }
    });
}

// Download App Function - Enhanced and Fixed
function downloadApp(event) {
    event.preventDefault();
    
    // Create a more realistic download simulation
    const downloadBtn = event.target.closest('.download-btn');
    const originalText = downloadBtn.innerHTML;
    
    // Show loading state
    downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Preparing Download...';
    downloadBtn.disabled = true;
    
    // Simulate download preparation
    setTimeout(() => {
        downloadBtn.innerHTML = '<i class="fas fa-download"></i> Downloading...';
        
        // Show success message
        setTimeout(() => {
            downloadBtn.innerHTML = '<i class="fas fa-check"></i> Download Started!';
            downloadBtn.style.background = 'var(--color-success)';
            
            // Reset button after 3 seconds
            setTimeout(() => {
                downloadBtn.innerHTML = originalText;
                downloadBtn.disabled = false;
                downloadBtn.style.background = '';
            }, 3000);
        }, 1000);
    }, 1500);
    
    // Show download modal
    showDownloadModal();
}

// Download Modal - Enhanced and Fixed
function showDownloadModal() {
    // Remove existing modal if present
    const existingModal = document.querySelector('.download-modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'download-modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fab fa-android"></i> Download Quizzler</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="download-info">
                        <div class="qr-placeholder">
                            <i class="fas fa-qrcode"></i>
                            <p>QR Code</p>
                        </div>
                        <div class="download-details">
                            <h4>Get Quizzler for Android</h4>
                            <p>Experience personalized learning with AI-powered assessments across multiple engineering subjects</p>
                            <div class="download-features">
                                <div class="download-feature"><i class="fas fa-brain"></i><span>Adaptive Learning</span></div>
                                <div class="download-feature"><i class="fas fa-chart-line"></i><span>Progress Tracking</span></div>
                                <div class="download-feature"><i class="fas fa-shield-alt"></i><span>Secure Exams</span></div>
                                <div class="download-feature"><i class="fas fa-graduation-cap"></i><span>Multiple Subjects</span></div>
                            </div>
                            <button class="btn btn--primary btn--full-width" onclick="initiateDownload()">
                                <i class="fab fa-google-play"></i>
                                Coming Soon to Google Play
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal styles
    if (!document.querySelector('#modal-styles')) {
        const modalStyles = document.createElement('style');
        modalStyles.id = 'modal-styles';
        modalStyles.textContent = `
            .download-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 10000;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .download-modal.active {
                opacity: 1;
                visibility: visible;
            }
            
            .download-info {
                display: flex;
                gap: var(--space-24);
                align-items: center;
            }
            
            .qr-placeholder {
                width: 120px;
                height: 120px;
                background: var(--color-bg-1);
                border-radius: var(--radius-base);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: var(--space-8);
            }
            
            .qr-placeholder i {
                font-size: var(--font-size-4xl);
                color: var(--color-primary);
            }
            
            .qr-placeholder p {
                margin: 0;
                font-size: var(--font-size-sm);
                color: var(--color-text-secondary);
            }
            
            .download-details {
                flex: 1;
            }
            
            .download-details h4 {
                margin-bottom: var(--space-8);
                color: var(--color-text);
            }
            
            .download-details > p {
                color: var(--color-text-secondary);
                margin-bottom: var(--space-16);
            }
            
            .download-features {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: var(--space-8);
                margin-bottom: var(--space-20);
            }
            
            .download-feature {
                display: flex;
                align-items: center;
                gap: var(--space-8);
            }
            
            .download-feature i {
                color: var(--color-primary);
                width: 16px;
            }
            
            .download-feature span {
                color: var(--color-text-secondary);
                font-size: var(--font-size-sm);
            }
            
            @media (max-width: 768px) {
                .download-info {
                    flex-direction: column;
                    text-align: center;
                }
                
                .qr-placeholder {
                    width: 100px;
                    height: 100px;
                }
                
                .download-features {
                    grid-template-columns: 1fr;
                }
            }
        `;
        
        document.head.appendChild(modalStyles);
    }
    
    document.body.appendChild(modal);
    
    // Add close functionality
    modal.querySelector('.modal-close').addEventListener('click', closeDownloadModal);
    modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) {
            closeDownloadModal();
        }
    });
    
    // Show modal with animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 50);
}

function closeDownloadModal() {
    const modal = document.querySelector('.download-modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function initiateDownload() {
    // Create a demo file download with updated content
    const demoContent = `Welcome to Quizzler!

This is a demonstration of our AI-powered learning application featuring multiple engineering subjects.

Available Quizzes:
✓ DBMS Quiz - Database Management Systems
✓ Data Structures Quiz - Arrays, Trees, Graphs & More
✓ Algorithms Quiz - Sorting, Searching & Optimization
✓ Operating Systems Quiz - Process Management & Memory
✓ Computer Networks Quiz - Protocols & Network Architecture

Features:
✓ Adaptive Assessments with 82% accuracy
✓ Personalized Learning Paths
✓ Focus Mode for distraction-free learning
✓ Secure Exam Mode with anti-cheating measures
✓ Progress tracking across all subjects

Powered by 5 Advanced AI Models:
- Decision Tree (82% accuracy)
- Support Vector Machine (78% accuracy) 
- Bayesian Network (80% accuracy)
- RNN-LSTM (MSE: 0.05)
- K-Nearest Neighbors (80% accuracy)

Results:
• 15% improvement in test scores
• Enhanced student engagement
• Better learning outcomes across engineering subjects

Developed by the team at Thakur College of Engineering & Technology, Mumbai.

Thank you for your interest in Quizzler!
The full Android app with all engineering subjects will be available on Google Play Store soon.`;

    const blob = new Blob([demoContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Quizzler-Engineering-Subjects-Demo.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    closeDownloadModal();
}

// Add scroll progress indicator
function addScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    progressBar.innerHTML = '<div class="scroll-progress-bar"></div>';
    
    const progressStyles = document.createElement('style');
    progressStyles.textContent = `
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: rgba(var(--color-brown-600-rgb, 94, 82, 64), 0.1);
            z-index: 1001;
        }
        
        .scroll-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--color-primary), var(--color-primary-hover));
            width: 0%;
            transition: width 0.1s ease;
        }
    `;
    
    document.head.appendChild(progressStyles);
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const maxScroll = document.body.scrollHeight - window.innerHeight;
        const progress = (scrolled / maxScroll) * 100;
        
        const progressBarElement = document.querySelector('.scroll-progress-bar');
        if (progressBarElement) {
            progressBarElement.style.width = `${Math.min(progress, 100)}%`;
        }
    });
}

// Add keyboard navigation support
document.addEventListener('keydown', function(e) {
    // Close modal with Escape key
    if (e.key === 'Escape') {
        const modals = document.querySelectorAll('.download-modal.active, .quiz-preview-modal.active, .demo-modal.active');
        modals.forEach(modal => {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        });
    }
});

// Add loading animation
window.addEventListener('load', function() {
    document.body.classList.add('loaded');
    
    // Add a subtle fade-in for the entire page
    if (!document.querySelector('#loading-styles')) {
        const loadingStyles = document.createElement('style');
        loadingStyles.id = 'loading-styles';
        loadingStyles.textContent = `
            body {
                opacity: 0;
                transition: opacity 0.5s ease-in-out;
            }
            
            body.loaded {
                opacity: 1;
            }
        `;
        document.head.appendChild(loadingStyles);
    }
});

// Add interactive hover effects for enhanced user experience
document.addEventListener('DOMContentLoaded', function() {
    // Add floating animation to feature cards
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('animate');
        }, 200 + (index * 100));
    });
    
    // Add glow effect to tech cards
    const techCards = document.querySelectorAll('.tech-card');
    techCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('animate');
        }, 300 + (index * 100));
    });

    // Add team card animations
    const teamCards = document.querySelectorAll('.team-card');
    teamCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('animate');
        }, 400 + (index * 100));
    });

    // Add benefit animations
    const benefits = document.querySelectorAll('.benefit');
    benefits.forEach((benefit, index) => {
        setTimeout(() => {
            benefit.classList.add('animate');
        }, 500 + (index * 100));
    });

    // Add testimonial animation
    const testimonial = document.querySelector('.testimonial');
    if (testimonial) {
        setTimeout(() => {
            testimonial.classList.add('animate');
        }, 800);
    }
});