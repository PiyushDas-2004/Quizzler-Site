// Global variables
let isScrolling = false;

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initSmoothScrolling();
    initScrollAnimations();
    initCounterAnimations();
    initMobileMenu();
    initParallaxEffects();
    initHeaderScroll(); // Updated for shrink class
    initDownloadButtons();
    addScrollProgress();
});

/****************************
 * Download Buttons
 ***************************/
function initDownloadButtons() {
    const downloadButtons = document.querySelectorAll('.download-btn');
    downloadButtons.forEach(button => {
        button.addEventListener('click', downloadApp);
    });
}

function downloadApp(event) {
    event.preventDefault();

    const downloadBtn = event.target.closest('.download-btn');
    if (!downloadBtn) return;

    const originalHTML = downloadBtn.innerHTML;
    downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Preparing...';
    downloadBtn.disabled = true;

    setTimeout(() => {
        downloadBtn.innerHTML = '<i class="fas fa-download" aria-hidden="true"></i> Downloading...';

        // Trigger actual download via hidden link
        const link = document.createElement('a');
        link.href = downloadBtn.getAttribute('href') || 'downloads/Quizzler.apk';
        link.download = 'Quizzler.apk';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Show completed state
        setTimeout(() => {
            downloadBtn.innerHTML = '<i class="fas fa-check" aria-hidden="true"></i> Started!';
            downloadBtn.style.background = 'var(--color-success)';

            setTimeout(() => {
                downloadBtn.innerHTML = originalHTML;
                downloadBtn.style.background = '';
                downloadBtn.disabled = false;
            }, 2500);
        }, 800);
    }, 1200);
}

/****************************
 * Smooth Scrolling Navigation
 ***************************/
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            // external or empty anchor
            if (!targetId || targetId === '#') return;
            e.preventDefault();

            const targetEl = document.querySelector(targetId);
            if (targetEl) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const topPos = targetEl.offsetTop - headerHeight - 20;
                if (!isScrolling) {
                    isScrolling = true;
                    window.scrollTo({ top: topPos, behavior: 'smooth' });
                    setTimeout(() => (isScrolling = false), 1000);
                }
            }
        });
    });
}

/****************************
 * Scroll Animations (IntersectionObserver)
 ***************************/
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    }, { threshold: 0.15 });

    document.querySelectorAll('.feature-card, .tech-card, .team-card, .benefit, .testimonial').forEach(el => observer.observe(el));
}

/****************************
 * Counter Animations
 ***************************/
function initCounterAnimations() {
    const counters = document.querySelectorAll('.stat__number[data-target]');
    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.6 });
    counters.forEach(c => obs.observe(c));
}

function animateCounter(el) {
    const target = +el.dataset.target;
    const duration = 1800;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        el.textContent = Math.floor(current).toLocaleString();
    }, 16);
}

/****************************
 * Mobile Menu
 ***************************/
function initMobileMenu() {
    const toggle = document.querySelector('.nav__toggle');
    const menu = document.querySelector('.nav__menu');
    if (!toggle || !menu) return;

    toggle.addEventListener('click', () => {
        menu.classList.toggle('active');
        toggle.classList.toggle('active');
        const icon = toggle.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });

    menu.querySelectorAll('.nav__link').forEach(link => {
        link.addEventListener('click', () => {
            menu.classList.remove('active');
            toggle.classList.remove('active');
            const icon = toggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        });
    });
}

/****************************
 * Parallax floating particles
 ***************************/
function initParallaxEffects() {
    window.addEventListener('scroll', () => {
        const y = window.pageYOffset;
        document.querySelectorAll('.particle').forEach((p, idx) => {
            const speed = 0.3 + idx * 0.05;
            p.style.transform = `translateY(${-(y * speed)}px)`;
        });
    });
}

/****************************
 * Header Scroll Shrink
 ***************************/
function initHeaderScroll() {
    const header = document.querySelector('.header');
    if (!header) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.classList.add('header--shrink');
            header.style.background = 'rgba(255, 255, 255, 0.2)';
            header.style.backdropFilter = 'blur(20px)';
        } else {
            header.classList.remove('header--shrink');
            header.style.background = 'rgba(255, 255, 255, 0.1)';
            header.style.backdropFilter = 'blur(10px)';
        }
    });
}

/****************************
 * Scroll Progress Bar
 ***************************/
function addScrollProgress() {
    const barWrapper = document.createElement('div');
    barWrapper.className = 'scroll-progress';
    barWrapper.innerHTML = '<div class="scroll-progress-bar"></div>';

    const style = document.createElement('style');
    style.textContent = `
        .scroll-progress{position:fixed;top:0;left:0;width:100%;height:3px;background:rgba(var(--color-brown-600-rgb,94,82,64),0.1);z-index:1100}
        .scroll-progress-bar{height:100%;background:linear-gradient(90deg,var(--color-primary),var(--color-primary-hover));width:0%;transition:width .1s}
    `;
    document.head.appendChild(style);
    document.body.appendChild(barWrapper);

    const bar = barWrapper.firstElementChild;
    window.addEventListener('scroll', () => {
        const max = document.body.scrollHeight - window.innerHeight;
        const percent = (window.pageYOffset / max) * 100;
        bar.style.width = Math.min(percent, 100) + '%';
    });
}
